﻿class PruebaDeRecuadro
{
    static void Main()
    {
        RecuadroRelleno r1 = new RecuadroRelleno();
        r1.SetX(3);
        r1.SetY(4);
        r1.SetAnchura(5);
        r1.SetAltura(3);
        r1.SetCaracter('X');
        r1.Dibujar();

        RecuadroRelleno r2 = new RecuadroRelleno();
        r2.SetX(6);
        r2.SetY(5);
        r2.SetAnchura(20);
        r2.SetAltura(10);
        r2.SetCaracter('.');
        r2.Dibujar();
    }
}

