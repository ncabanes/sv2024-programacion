namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btSumar_Click(object sender, EventArgs e)
        {
            try
            {
                lResultado.Text =
                    Convert.ToString(
                        Convert.ToInt32(tbNumero1.Text)
                        + Convert.ToInt32(tbNumero2.Text)
                    );

                listBox1.Items.Add(
                    tbNumero1.Text + "+" +
                    tbNumero2.Text + " = " +
                    lResultado.Text);
            }
            catch (Exception)
            {
                lResultado.Text = "Imposible sumar";
                MessageBox.Show("N�mero no v�lido");
            }
        }

        private void btRestar_Click(object sender, EventArgs e)
        {
            try
            {
                lResultado.Text =
                    Convert.ToString(
                        Convert.ToInt32(tbNumero1.Text)
                        - Convert.ToInt32(tbNumero2.Text)
                    );

                listBox1.Items.Add(
                    tbNumero1.Text + "-" +
                    tbNumero2.Text + " = " +
                    lResultado.Text);
            }
            catch (Exception)
            {
                lResultado.Text = "Imposible restar";
                MessageBox.Show("N�mero no v�lido");
            }
        }
    }
}
