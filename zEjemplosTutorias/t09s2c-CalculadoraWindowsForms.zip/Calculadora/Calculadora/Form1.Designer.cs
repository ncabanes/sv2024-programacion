﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbNumero1 = new TextBox();
            tbNumero2 = new TextBox();
            lResultado = new Label();
            btSumar = new Button();
            btRestar = new Button();
            listBox1 = new ListBox();
            SuspendLayout();
            // 
            // tbNumero1
            // 
            tbNumero1.Location = new Point(37, 27);
            tbNumero1.Name = "tbNumero1";
            tbNumero1.Size = new Size(100, 23);
            tbNumero1.TabIndex = 0;
            // 
            // tbNumero2
            // 
            tbNumero2.Location = new Point(35, 72);
            tbNumero2.Name = "tbNumero2";
            tbNumero2.Size = new Size(102, 23);
            tbNumero2.TabIndex = 1;
            // 
            // lResultado
            // 
            lResultado.AutoSize = true;
            lResultado.Location = new Point(64, 115);
            lResultado.Name = "lResultado";
            lResultado.Size = new Size(67, 15);
            lResultado.TabIndex = 2;
            lResultado.Text = "(Resultado)";
            // 
            // btSumar
            // 
            btSumar.Location = new Point(176, 37);
            btSumar.Name = "btSumar";
            btSumar.Size = new Size(75, 23);
            btSumar.TabIndex = 3;
            btSumar.Text = "Sumar";
            btSumar.UseVisualStyleBackColor = true;
            btSumar.Click += btSumar_Click;
            // 
            // btRestar
            // 
            btRestar.Location = new Point(176, 66);
            btRestar.Name = "btRestar";
            btRestar.Size = new Size(75, 23);
            btRestar.TabIndex = 4;
            btRestar.Text = "Restar";
            btRestar.UseVisualStyleBackColor = true;
            btRestar.Click += btRestar_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(287, 30);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(117, 109);
            listBox1.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(438, 187);
            Controls.Add(listBox1);
            Controls.Add(btRestar);
            Controls.Add(btSumar);
            Controls.Add(lResultado);
            Controls.Add(tbNumero2);
            Controls.Add(tbNumero1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tbNumero1;
        private TextBox tbNumero2;
        private Label lResultado;
        private Button btSumar;
        private Button btRestar;
        private ListBox listBox1;
    }
}
