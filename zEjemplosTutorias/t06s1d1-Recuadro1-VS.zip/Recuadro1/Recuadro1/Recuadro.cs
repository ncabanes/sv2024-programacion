﻿using System;

class Recuadro
{
    private byte x, y, anchura, altura;
    private char caracter;

    public int GetX() { return x; }
    public int GetY() { return y; }
    public int GetAnchura() { return anchura; }
    public int GetAltura() { return altura; }
    public char GetCaracter() { return caracter; }

    public void SetX(int nuevaX) { x = (byte) nuevaX; }
    public void SetY(int nuevaY) { y = (byte) nuevaY; }
    public void SetAnchura(int nuevaAnchura) { anchura = (byte) nuevaAnchura; }
    public void SetAltura(int nuevaAltura) { altura = (byte) nuevaAltura; }
    public void SetCaracter(char nuevoCaracter) { caracter = nuevoCaracter; }

    public void Dibujar()
    {
        // Primera fila
        for (int i = 0; i < anchura; i++)
        {
            Console.SetCursorPosition(x+i, y);
            Console.WriteLine(caracter);
        }

        // Filas intermedias
        for (int fila  = 1; fila < altura-1; fila++)
        {
            Console.SetCursorPosition(x, y+fila);
            Console.WriteLine(caracter);

            Console.SetCursorPosition(x+anchura-1, y + fila);
            Console.WriteLine(caracter);
        }

        // Ultima fila
        for (int i = 0; i < anchura; i++)
        {
            Console.SetCursorPosition(x + i, y+altura-1);
            Console.WriteLine(caracter);
        }
    }
}

