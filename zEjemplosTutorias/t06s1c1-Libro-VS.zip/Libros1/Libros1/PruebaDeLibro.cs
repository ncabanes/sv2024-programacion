﻿class PruebaDeLibro
{
    static void Main()
    {
        Libro l = new Libro();
        l.SetAutor("Stephen King");
        l.SetTitulo("It");
        l.SetUbicacion("e3b4");

        l.MostrarDetalles();
    }
}

