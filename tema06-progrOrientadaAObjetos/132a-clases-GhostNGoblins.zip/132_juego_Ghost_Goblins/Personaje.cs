﻿using System;


class Personaje {

    private int x, y;
    public void MoverIzquierda() {
        x--;
    }

    public void MoverDerecha() {
        x++;
    }

    public void Saltar() {

    }

    public void MoverArriba() {
        y++;
    }

    public void MoverAbajo() {
        y--;
    }

    public void Disparar() { 
    
    }

    public void PerderArmadura() { 
    
    }

    public void PerderVida() { 
    
    }

}
