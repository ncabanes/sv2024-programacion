﻿using System;

class Partida {

    public void IniciarEscenario() { 
    
        
    
    }

}