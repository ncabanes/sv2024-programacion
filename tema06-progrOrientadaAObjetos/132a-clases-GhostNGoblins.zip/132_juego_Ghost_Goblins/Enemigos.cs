﻿using System;

class Enemigo {

    private int x;
    private bool eliminado = false;

    public void MoverIzquierda() {
        x--;
    }

    public void MoverDerecha() {
        x++;
    }

    public void Disparar() { 
    
    }

    public void Eliminar() {
        eliminado = true;
    }

}

