﻿using System;

class Marcador {

    public void IniciarMarcador() { 
    
        
    
    }

}