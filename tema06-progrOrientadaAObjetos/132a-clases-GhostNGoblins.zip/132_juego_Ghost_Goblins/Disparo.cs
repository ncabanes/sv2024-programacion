﻿using System;

class Disparo {

    public void Disparar() { 
        

    
    }

}
