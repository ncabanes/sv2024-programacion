﻿/* Nombre: Andrés (...)
 * Curso: 1º DAM. Semipresencial 2024-2025 */

/* Ejercicio 132. Implementación aproximada Juego Ghost Goblins.
 * 
 * Implementa las clases que has diseñado en tu diagrama.
 * 
 * Todavía no habrá detalles avanzados que veremos más adelante, como herencias
 * o agregaciones. Aparecerán los nombres de los métodos, pero éstos estarán
 * vacíos.
 * 
 * Deberás entregar, comprimido en ZIP, todo el proyecto de Visual Studio (un
 * fichero para cada clase), que debe compilar correctamente aunque "no haga
 * nada útil". */
 
using System;

class Juego {

    static void Main() {


    }
}
