﻿using System;


class Sprite {



}

