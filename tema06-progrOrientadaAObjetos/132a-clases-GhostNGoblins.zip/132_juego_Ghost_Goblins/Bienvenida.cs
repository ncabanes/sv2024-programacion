﻿using System;


class Bienvenida {

    public void Iniciar() { 
    
        
    
    }

}

